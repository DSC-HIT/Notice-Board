# Notice-Board
Android app which gives information about everything from class schedule and important announcements to class notes and much more
For more information about the project visit: https://docs.google.com/document/d/1HFMtEkRi2rDK6NsX6aNkaDUpAMx3yB9wdheZMeLSaZE/edit?usp=sharing

For live demonstration of the application see this video.
https://youtu.be/ejHj5kbf-Uk
